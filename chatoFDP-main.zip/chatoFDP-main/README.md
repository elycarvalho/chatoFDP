# chatoFDP
(chat **O**riented **F**or **D**umb **P**eople)

Mini chatbot feito para descontrair que tenta responder perguntas, mas nem sempre dá a resposta que o usuario quer.
* Além de responder algumas perguntas, realiza operações básicas de matemática, como adição, subtração, divisão e multiplicação.
* Tambem converte milhas em quilometros.
* Desenvolvido usando as linguagens HTML/CSS e Javascript.
